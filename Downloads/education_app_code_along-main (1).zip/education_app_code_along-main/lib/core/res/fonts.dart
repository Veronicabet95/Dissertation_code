
class Fonts {
  static const poppins = 'Poppins';
  static const aeonik = 'Aeonik';
}
